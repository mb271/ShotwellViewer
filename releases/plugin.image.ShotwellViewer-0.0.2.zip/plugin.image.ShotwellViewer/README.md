ShotwellViewer
=========================

An xbmc-plugin to view shotwell database files.

icon.png is the icon used by shotwell.

